package com.spring.empDetails;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringEmpApplication {

	public static void main(String[] args) {
	System.out.print("I am here");
		SpringApplication.run(SpringEmpApplication.class, args);
	}

}
